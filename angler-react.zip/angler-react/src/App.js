import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import logo from './logo.svg';
import './App.css';
import Category from './components/Category/Category'
import Product from './components/Product/Product'
import CategoryDetails from './components/CategoryDetails/CategoryDetails'
import Menu from './components/Menu/Menu';
import ProductList from './components/Product/ProductList'
function App() {
  return (
    <div className="App">
      <Router>
        <Menu />
        <Switch>


          <Route exact path="/" component={Category} />
          <Route exact path="/product" component={ProductList} />
          <Route exact path="/product/create" component={Product} />
          <Route exact path="/category-details/:id" component={CategoryDetails} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
