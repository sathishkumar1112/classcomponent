import React, { Component } from "react";
import { IonMenu, IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonLabel, IonItem, IonRouterOutlet } from '@ionic/react';


class Menu extends Component {


  render() {
    return (

      <>

        <ion-app>
          <ion-menu side="start" content-id="main-content">
            <ion-header>
              <ion-toolbar translucent>
                <ion-title>Menu</ion-title>
              </ion-toolbar>
            </ion-header>
            <ion-content>
              <ion-list>
                <IonItem routerLink="/" routerDirection="none">
                  <IonLabel color="light">Category List</IonLabel>
                </IonItem>
                <IonItem routerLink="/product" routerDirection="none">
                  <IonLabel color="light">Product List</IonLabel>
                </IonItem>
              </ion-list>
            </ion-content>
          </ion-menu>

          <div className="ion-page" id="main-content">
            <ion-header>
              <ion-toolbar>
                <ion-buttons slot="start">
                  <ion-menu-button></ion-menu-button>
                </ion-buttons>

              </ion-toolbar>
            </ion-header>
            <ion-content className="ion-padding">
              <ion-button expand="block" onclick="openMenu()">Open Menu</ion-button>
            </ion-content>
          </div>
        </ion-app>


      </>
    )
  }

}

export default Menu
