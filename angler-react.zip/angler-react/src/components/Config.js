export default {
  API_BASEURL: "http://localhost:8000/",

};
