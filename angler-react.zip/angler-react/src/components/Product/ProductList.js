import React, { Component } from "react";
import { IonList, IonItem, IonLabel, IonListHeader, IonButton, IonImg, IonHeader, IonToolbar, IonButtons, IonBackButton, IonSearchbar } from '@ionic/react';
import axios from 'axios'
import Config from '../Config';
class ProductList extends Component {

  constructor() {
    super();
    this.state = {
      product_list: [],
      product_name: '',
      image_url: ''
    }
    this.onChange = this.onChange.bind(this)
  }

  onChange = (event) => {
    if (event.target.value != '') {
      this.setState({ product_name: event.target.value })
    }
    else {
      this.setState({ product_name: '' })
      this.getProduct();
    }

  }
  addPage = () => {
    this.props.history.push('/product/create')
  }
  onSubmit = (event) => {
    event.preventDefault();
    let url = Config.API_BASEURL + 'api/search-products?name=' + this.state.product_name
    axios.get(url)
      .then(res => {
        this.setState({
          product_list: res.data,
          image_url: res.config.url
        });
      })
      .catch(err => {
        console.log(err)
      })
  }
  getProduct = async () => {
    let url = Config.API_BASEURL + "api/product";
    await axios.get(url).then(res => {
      console.log(res)
      this.setState({
        product_list: res.data,
        image_url: res.config.url
      });
    })
  }

  async componentDidMount() {
    await this.getProduct();
  }

  render() {
    return (
      <>
        <ion-grid>
          <ion-row>
            <ion-col size="3" offset="9">
              <IonButton className="ion-margin-top" onClick={this.addPage}>
                Add Product
                </IonButton>
            </ion-col>
          </ion-row>
        </ion-grid>
        <ion-grid>
          <ion-row>
            <ion-col size="3" offset="5">
              <form >
                <ion-col size="3" >
                  <IonSearchbar showCancelButton="always" value={this.state.product_name} onIonChange={this.onChange} ></IonSearchbar>
                </ion-col>
                <ion-col size="3" >
                  <IonButton onClick={this.onSubmit} >Submit</IonButton>
                </ion-col>
              </form>
            </ion-col>
          </ion-row>
        </ion-grid>
        <IonList >
          <ion-grid>
            <ion-row>

              <ion-col size="10" offset="1">
                <IonListHeader lines="inset">

                  <IonLabel>Category Name</IonLabel>

                  <IonLabel>Product Code</IonLabel>

                  <IonLabel>Product Image</IonLabel>

                  <IonLabel>Description</IonLabel>
                </IonListHeader>
              </ion-col>
              <ion-col size="10" offset="1">
                {this.state.product_list.length > 0 ? (
                  this.state.product_list.map((item, index) => {
                    return (

                      <IonItem key={item.id}>
                        <IonLabel color="primary" key={item.id}>
                          {item.product_name}
                        </IonLabel>
                        <IonLabel color="primary" key={item.id}>
                          {item.product_code}
                        </IonLabel>
                        <IonLabel color="primary" key={item.id}>
                          <IonImg src={item.image} key={item.id} style={{ height: "150px", height: '100px' }} />
                        </IonLabel>
                        <IonLabel color="primary" key={item.id}>
                          {item.description}
                        </IonLabel>
                      </IonItem>
                    )
                  })
                )
                  : (<IonItem><IonLabel color="primary">
                    Data not exist
        </IonLabel></IonItem>)

                }
              </ion-col>
            </ion-row>
          </ion-grid>
        </IonList >
      </>
    )
  }
}

export default ProductList
