import React, { Component } from "react";
import { IonItem, IonLabel, IonInput, IonSelect, IonSelectOption, IonCard, IonTextarea, IonButton, Ion } from '@ionic/react';
import axios from 'axios'
import Config from '../Config';
class Product extends React.Component {

  constructor() {
    super();
    this.state = {
      product_name: '',
      product_code: '',
      product_image: '',
      product_description: '',
      category_list: [],
      category_name: [],
      supported_mime: [
        'image/jpeg',
        'image/jpg',
      ]
    }

    this.handleInputChange = this.handleInputChange.bind(this);
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  handleInputChange(event) {
    let size = this.ValidateSize(event.target.files)
    if (size == false) {
      alert('filze size must be 2Mb')
      this.setState({

        product_image: ''

      });
    }
    else {

      this.setState({
        ...event.target.files,
        product_image: event.target.files[0]

      });
    }
  }
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value })

  }
  goListPage = () => {
    this.props.history.push('/product')
  }
  ValidateSize = (file) => {
    if (file.length > 0) {
      var FileSize = file[0].size / 1024 / 1024; // in MiB
      if (FileSize > 2) {
        return false

      } else {
        return true
      }
    }
  }

  onSubmit(event) {
    event.preventDefault()
    const data = new FormData()
    data.append('file', this.state.product_image)
    data.append('product_name', this.state.product_name)
    data.append('product_code', this.state.product_code)
    data.append('category', this.state.category_name)
    data.append('product_description', this.state.product_description)

    // let url = Config.API_BASEURL + "api/product";
    // console.log(data);
    // axios.post(url, data, { 'Content-Type': 'multipart/form-data' })
    //   .then(res => {
    //     console.warn(res);
    //   })
    //   .catch(err => {
    //     console.log(err);
    //   })

  }

  getCategoryList = async () => {
    let url = Config.API_BASEURL + "api/getallcategory";
    await axios.get(url).then(res => {
      console.log(res)
      this.setState({
        category_list: res.data
      });
    })
  }

  async componentDidMount() {
    await this.getCategoryList();
  }

  render() {

    return (
      <div>
        <ion-grid>
          <ion-row>
            <ion-col size="3" offset="9">
              <IonButton className="ion-margin-top" onClick={this.goListPage}>
                Back
                </IonButton>
            </ion-col>
          </ion-row>
        </ion-grid>
        <ion-grid>
          <ion-row>

            <ion-col size="6" offset="3">
              <IonCard>


                <form className="ion-padding" encType="multipart/form-data" id='form'>
                  <IonItem>
                    <IonLabel position="floating">Product Name</IonLabel>
                    <IonInput name="product_name" value={this.state.product_name} onIonInput={this.onChange} required />
                  </IonItem>
                  <IonItem>
                    <IonLabel position="floating">Product Code</IonLabel>
                    <IonInput name="product_code" value={this.state.product_code} onIonInput={this.onChange} required />
                  </IonItem>
                  <IonItem>
                    <IonLabel>Category</IonLabel>
                    <IonSelect name='category_name' value={this.state.category_name} placeholder="Select One" multiple={true} cancelText="Cancel" okText="OK" onIonChange={this.onChange}>
                      {this.state.category_list.length > 0 ? (
                        this.state.category_list.map((item, index) => {

                          return (<IonSelectOption value={item.id} key={item.id}>{item.category_name}</IonSelectOption>)
                        })
                      ) : (<IonSelectOption value="">Category not available</IonSelectOption>)

                      }
                    </IonSelect>
                  </IonItem>
                  <IonItem>
                    <IonLabel position="stacked">Product Image</IonLabel>
                    <input type="file" name="product_image" accept={this.state.supported_mime} onChange={this.handleInputChange} required />

                  </IonItem>
                  <IonItem>
                    <IonLabel position="floating">Description</IonLabel>
                    <IonTextarea name="product_description" value={this.state.product_description} onIonInput={this.onChange} ></IonTextarea>
                  </IonItem>
                  <ion-grid>
                    <ion-row>
                      <ion-col size="3" offset="5">
                        <IonButton className="ion-margin-top" expand="block" onClick={this.onSubmit}>
                          Submit
                </IonButton>
                      </ion-col>
                    </ion-row>
                  </ion-grid>

                </form>

              </IonCard>
            </ion-col>
          </ion-row>
        </ion-grid>
      </div>
    )
  }
}

export default Product
