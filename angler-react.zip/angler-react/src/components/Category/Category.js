import React, { Component } from "react";
import ReactDOM from 'react-dom'
import { IonList, IonItem, IonLabel, IonInput, IonToggle, IonRadio, IonCard, IonCheckbox, IonItemSliding, IonItemOption, IonItemOptions, IonToast, IonButton } from '@ionic/react';
import axios from 'axios'
import FormData from 'form-data'
import List from './List'
import Config from '../Config';
class Category extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      category_name: '',
      category_list: []
    }
  }

  getCategoryList = async () => {
    let url = Config.API_BASEURL + "api/category";
    await axios.get(url).then(res => {
      console.log(res)
      this.setState({
        category_list: res.data.data
      });
    })
  }

  async componentDidMount() {
    await this.getCategoryList();
  }

  onChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  }
  nextPage = async id => {
    this.props.history.push('/category-details/' + id)

  }

  onSubmit = event => {
    event.preventDefault();
    const body = {
      "category_name": this.state.category_name,
    };
    let url = Config.API_BASEURL + "api/category";
    var config = {
      mode: 'no-cors',
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': 'GET, PUT, POST, DELETE, OPTIONS'
      }
    }
    axios.post(url, body, config)
      .then(res => {
        if (res.status == 201 || res.status == 200) {
          this.getCategoryList();
        }
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      })
  }
  componentWillUnmount() {
    this.getCategoryList();
  }


  render() {
    return (
      <div>
        <ion-grid>
          <ion-row>
            <ion-col size="6" offset="3">
              <IonCard>
                <form className="ion-padding">
                  <IonItem>
                    <IonLabel position="floating">Category Name</IonLabel>
                    <IonInput name="category_name" value={this.state.category_name} onIonInput={this.onChange} />
                  </IonItem>
                  <ion-grid>
                    <ion-row>
                      <ion-col size="3" offset="5">
                        <IonButton className="ion-margin-top" expand="block" onClick={this.onSubmit}>
                          Submit
                      </IonButton>
                      </ion-col>
                    </ion-row>
                  </ion-grid>
                </form>
              </IonCard>
            </ion-col>
          </ion-row>
        </ion-grid>
        <List list={this.state.category_list} nextPage={this.nextPage} />
      </div>
    )
  }
}

export default Category
