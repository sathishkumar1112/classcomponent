import React, { Component } from "react";
import { IonList, IonItem, IonLabel, IonListHeader, IonButton } from '@ionic/react';

const List = (props) => {
  const { list, nextPage, ...propsOrg } = props;

  return (
    <>

      <IonList>
        <ion-grid>
          <ion-row>
            <ion-col size="6" offset="3">
              <IonListHeader lines="inset">
                <IonLabel>Category List</IonLabel>
                <IonLabel>Action</IonLabel>

              </IonListHeader>
            </ion-col>
            <ion-col size="6" offset="3">
              {list.length > 0 ? (
                list.map((item, index) => {
                  return (

                    <IonItem key={index}>
                      <IonLabel color="primary">
                        {item.category_name}
                      </IonLabel>
                      <IonLabel color="primary" key={index}>
                        <IonButton className="ion-margin-top" onClick={() => {
                          nextPage(item.id);
                        }}>
                          View
                      </IonButton>
                      </IonLabel>
                    </IonItem>



                  )
                })) : (<IonItem><IonLabel color="primary">
                  Data not exist
        </IonLabel></IonItem>)
              }
            </ion-col>
          </ion-row>
        </ion-grid>


      </IonList >
    </>

  )

}



export default List
