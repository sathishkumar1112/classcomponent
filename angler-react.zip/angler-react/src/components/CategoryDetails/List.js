import React, { Component } from "react";
import { IonList, IonItem, IonLabel, IonListHeader, IonButton } from '@ionic/react';

const List = (props) => {
  const { list, ...propsOrg } = props;

  return (
    <>

      <IonList>
        <ion-grid>
          <ion-row>
            <ion-col size="6" offset="3">
              <IonListHeader lines="inset">
                <IonLabel>Category Name</IonLabel>
                <IonLabel>SubCategory Name</IonLabel>


              </IonListHeader>
            </ion-col>
            <ion-col size="6" offset="3">

              {list.length > 0 ? (
                list.map((item, index) => {
                  return (
                    <IonItem key={index}>
                      <IonLabel color="primary">
                        {item.category_id.category_name}
                      </IonLabel>
                      <IonLabel color="primary">
                        {item.name}
                      </IonLabel>
                      <IonLabel color="primary" key={index}>
                        <ion-icon ios="heart-outline" md="heart-sharp"></ion-icon>
                      </IonLabel>
                    </IonItem>



                  )
                })) : (<IonItem><IonLabel color="primary">
                  Data not exist
        </IonLabel></IonItem>)
              }
            </ion-col>
          </ion-row>
        </ion-grid>


      </IonList >
    </>

  )

}



export default List
