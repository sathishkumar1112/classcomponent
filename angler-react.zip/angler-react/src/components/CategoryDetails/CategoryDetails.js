import React, { Component } from "react";
import ReactDOM from 'react-dom'
import { IonList, IonItem, IonLabel, IonInput, IonToggle, IonRadio, IonCard, IonCheckbox, IonItemSliding, IonItemOption, IonItemOptions, IonToast, IonButton } from '@ionic/react';
import axios from 'axios'
import List from './List'
import Config from '../Config';
class CategoryDetails extends React.Component {
  constructor(props) {
    super(props);
    const {
      match: { params },
    } = props;
    this.state = {
      category_name: '',
      subcategory: '',
      subcategory_list: [],
      id: params.id
    }
  }

  getCategoryList = async () => {

    let url = Config.API_BASEURL + "api/category/" + this.state.id;
    await axios.get(url).then(res => {
      // console.log(res.data.category_name)
      this.setState({
        category_name: res.data.category_name
      });
    })
  }
  getSubCategoryList = async () => {

    let url = Config.API_BASEURL + "api/category-details";

    await axios.get(url).then(res => {
      console.log(res.data)
      this.setState({
        subcategory_list: res.data
      });
    })
  }

  async componentDidMount() {
    await this.getCategoryList();
    await this.getSubCategoryList();
  }
  onBack = () => {
    this.props.history.push('/')
  }
  onChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  }
  onSubmit = (event) => {
    event.preventDefault();
    const body = {
      "name": this.state.subcategory,
      "category_id": this.state.id
    };
    console.log(body)
    let url = Config.API_BASEURL + "api/category-details";
    var config = {
      mode: 'no-cors',
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
        'Access-Control-Allow-Methods': 'GET, PUT, POST, DELETE, OPTIONS'
      }
    }
    axios.post(url, body, config)
      .then(res => {
        // event.target.reset();
        console.log(res)
        if (res.status == 201 || res.status == 200) {
          this.getSubCategoryList();
          this.resetForm();
        }
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      })
  }
  render() {
    return (
      <>
        <ion-grid>
          <ion-row>
            <ion-col size="3" offset="10">
              <IonButton className="ion-margin-top" onClick={this.onBack}>
                Back
                </IonButton>
            </ion-col>
          </ion-row>
        </ion-grid>
        <ion-grid>
          <ion-row>
            <ion-col size="6" offset="3">
              <IonCard>

                <form className="ion-padding" id="form">
                  <IonItem>
                    <IonLabel position="floating">SubCategory Name</IonLabel>
                    <IonInput name="subcategory" value={this.state.subcategory} onIonInput={this.onChange} />
                  </IonItem>
                  <ion-grid>
                    <ion-row>
                      <ion-col size="3" offset="5">
                        <IonButton className="ion-margin-top" expand="block" onClick={this.onSubmit}>
                          Submit
                </IonButton>

                      </ion-col>
                    </ion-row>
                  </ion-grid>
                </form>
              </IonCard>
            </ion-col>
          </ion-row>
        </ion-grid>
        <List list={this.state.subcategory_list} />
      </>
    )
  }


}



export default CategoryDetails
